

<?php $__env->startSection('content'); ?>
<div class="container px-6 mx-auto grid">
    <h2 class="my-6 text-2xl font-semibold text-gray-700 dark:text-gray-200">
       Create User
    </h2>
     <!-- Menampilkan Pesan Error -->
     <?php if($errors->any()): ?>
     <div class="px-4 py-3 mb-8 bg-red-50 border border-red-400 text-red-700 rounded-lg">
         <ul>
             <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <li><?php echo e($error); ?></li>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </ul>
     </div>
 <?php endif; ?>

    <div class="px-4 py-3 mb-8 bg-white rounded-lg shadow-md dark:bg-gray-800">
        <form action="<?php echo e(isset($user) ? route('superadmin.users.update', $user->id) : route('superadmin.users.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php if(isset($user)): ?>
                <?php echo method_field('PUT'); ?>
            <?php endif; ?>

            <label class="block text-sm">
                <span class="text-gray-700 dark:text-gray-400">Name</span>
                <input class="block w-full mt-1 text-sm dark:border-gray-600 dark:bg-gray-700 form-input" name="name" value="<?php echo e(old('name', $user->name ?? '')); ?>" required />
            </label>

            <label class="block text-sm mt-4">
                <span class="text-gray-700 dark:text-gray-400">Email</span>
                <input class="block w-full mt-1 text-sm dark:border-gray-600 dark:bg-gray-700 form-input" name="email" value="<?php echo e(old('email', $user->email ?? '')); ?>" required />
            </label>

            <label class="block text-sm mt-4">
                <span class="text-gray-700 dark:text-gray-400">Password</span>
                <input type="password" class="block w-full mt-1 text-sm dark:border-gray-600 dark:bg-gray-700 form-input" name="password" <?php echo e(isset($user) ? '' : 'required'); ?> />
            </label>

            <label class="block text-sm mt-4">
                <span class="text-gray-700 dark:text-gray-400">Role</span>
                <select class="block w-full mt-1 text-sm dark:border-gray-600 dark:bg-gray-700 form-select" name="role_id" required>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="sa" >
                            <?php echo e($user->role); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </label>

            <div class="mt-6">
                <button type="submit" class="px-4 py-2 text-sm font-medium leading-5 text-white bg-purple-600 border border-transparent rounded-lg hover:bg-purple-700">
                    Create
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Driyo\Desktop\Project Magang Kominfo\PELADEN\resources\views/superadmin/users/create.blade.php ENDPATH**/ ?>