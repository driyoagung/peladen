
<?php $__env->startSection('content'); ?>
<!-- Remove everything INSIDE this div to a really blank page -->
<div class="container px-6 mx-auto grid">
    <h2 class="my-6 text-2xl font-semibold text-gray-700 dark:text-gray-200">
        Blank
    </h2>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Driyo\Desktop\Project Magang Kominfo\PELADEN\resources\views/admin/pages/blank.blade.php ENDPATH**/ ?>